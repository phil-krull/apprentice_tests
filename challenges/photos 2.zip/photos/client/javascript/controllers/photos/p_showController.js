app.controller('p_showController', function(photoFactory, $location, $routeParams, $cookies){
  var self = this;

  photoFactory.show($routeParams.id, $cookies.get('user_id'), function(photos){
    self.photos = photos;
    console.log(photos);
  })

  this.like = function(photo_id){
    photoFactory.like(photo_id, $cookies.get('user_id'), function(photos){
      $location.path('/photo');
    })
  }

  this.dislike = function(photo_id){
    photoFactory.dislike(photo_id, $cookies.get('user_id'),function(photos){
      $location.path('/photo');
    })
  }
})