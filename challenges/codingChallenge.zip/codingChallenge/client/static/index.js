$(document).ready(function(){
  var user = prompt("Enter your name");

  var socket = io.connect();

  if(user){
    socket.emit('newUser', {user: user});
  }

  $('button').on('click', function(){
    var chatroom = $('input').val();
    socket.emit('newChatroom', {chatroom: chatroom});
    $('input').val('');
  })

  socket.on('newUser', function(data){
    $('#users').append('<p>' + data.user + ' has joined the chatroom.</p>');
  })

  socket.on('newChatroom', function(data){
    console.log(data);
    for (var i = data.length - 1; i >= 0; i--) {
      console.log(data[i]);
      $('#chatrooms').append('<p>' + data[i].chatroom + ' <button type="submit" class="groupchat" value="' + data[i].chatroom + '">Enter</button></p>');
    };
    
  })

  $('.groupchat').on('click', function(){
    var room = $(this).attr('value');
    socket.emit('joiningRoom', {room: room});
  })

})