var express = require('express');
var app = express();
var path = require('path');

app.use(express.static(path.join(__dirname, '/client/static')));

app.set('views', path.join(__dirname, '/client/views'));

app.set('view engine', 'ejs');

app.get('/', function(req,res){
  res.render('index');
})

var server = app.listen(8000, function(){
  console.log('Listening on port 8000');
})

var io = require('socket.io').listen(server);

io.sockets.on('connection', function(socket){
  var chatrooms = [];
  console.log(socket.id);

  socket.on('newUser', function(data){
    socket.broadcast.emit('newUser', {user: data.user})
  })

  socket.on('newChatroom', function(data){
    chatrooms.push({chatroom: data.chatroom});
    io.emit('newChatroom', {chatroom: chatrooms});
  })

  socket.on('joiningRoom', function(data){
      console.log(chatrooms);
  })

})
