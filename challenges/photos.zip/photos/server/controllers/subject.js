var Subject = mongoose.model('subject');

module.exports = {

  
}