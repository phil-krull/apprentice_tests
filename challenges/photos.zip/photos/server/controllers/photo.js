var Photo = mongoose.model('photo');
var Subject = mongoose.model('subject');
var User = mongoose.model('user');

module.exports = {

  index: function(req, res){
    Photo.find({}).populate('user', 'subject').exec(function(errors, photos){
      if(errors){
        res.send(errors);
      } else {
        res.json(photos)
      }
    })
  },

  create: function(req, res){
    User.findOne({_id: req.params.id}, function(errors, user){
      if(errors){
        res.send(errors);
      } else {
        var newPhoto = new Photo(req.body);
        user.photo.push(newPhoto);
        user.save(errors){
          if(errors){
            res.send(errors);
          } else {
            newPhoto._user = user;
            newPhoto.save(function(errors){
              if(errors){
                res.send(errors);
              } else {
                res.json(true);
              }
            })
          }
        }
      }
    })
  },

  show: function(req, res){
    Photo.find({subject: req.params.subject}, {multi: true}, function(errors, photos){
      if(errors){
        res.send(errors);
      } else {
        res.json(photos);
      }
    })
  }

}