var User = mongoose.model('user');

module.exports = {

  create: function(req, res){
    var newUser = new User(req.body);
    User.create({first_name: req.body.first_name, last_name: req.body.last_name}, function(errors, user){
      if(errors){
        res.send(erros);
      } else {
        res.json(user);
      }
    })
  },

  show: function(req, res){
    User.find({_id: req.params.id}).populate('photos').exec(function(errors, user){
      if(errors){
        res.send(errors)
      } else {
        res.json(user);
      }
    })
  }
}