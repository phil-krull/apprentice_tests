var photoSchema = new mongoose.Schema({
  url: String,
  _user: {type: Schema.Types.ObjectId, ref: 'user'},
  subject: {type: Schema.Types.ObjectId, ref: 'subject'},
  likes: [{type: Schema.Types.ObjectId, ref: 'user'}],
  dislikes: [{type: Schema.Types.ObjectId, ref: 'user'}]
}, {timestamps: true});

mongoose.model('photo', photoSchema);