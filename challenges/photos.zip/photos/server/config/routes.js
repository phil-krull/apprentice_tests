var User = require('./../controllers/users.js');
var Photo = require('./../controllers/photo.js');
var Subject = require('./../controllers/subject.js');

module.exports = function(app){
  app.post('/users', User.create);

  app.get('/photos', Photo.index);

  app.post('/photos', Photo.create);

  app.get('/photos/subject', Photo.show);

  app.post('/photos/like', Photo.like);

  app.post('/photos/dislike', Photo.dislike);
}