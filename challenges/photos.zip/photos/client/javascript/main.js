var app = angular.module('myApp', ['ngRoute', 'ngCookies']);

app.config(function ($routeProvider){
  $routeProvider

  .when('/login', {
    templateUrl: 'partials/user/new.html',
    controller: 'userController',
    controllerAs: 'userCtrl'
  })
  .when('/user/:id', {
    templateUrl: 'partials/user/show.html',
    controller: 'userController',
    controllerAs: 'userCtrl'
  })
  .when('/photo', {
    templateUrl: 'partials/photo/index.html',
    controller: 'photoController',
    controllerAs: 'photoCtrl'
  })
  .when('/create', {
    templateUrl: 'partials/photo/new.html',
    controller: 'photoController',
    controllerAs: 'photoCtrl'
  })
  .when('/show', {
    templateUrl: 'partials/photo/show.html',
    controller: 'photoController',
    controllerAs: 'photoCtrl'
  })
  .otherwise({
    redirectTo: '/'
  })
})