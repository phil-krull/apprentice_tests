app.controller('userController', function(userFactory, $location, $cookies){
  var self = this;

  this.create = function(){
    userFactory.create(this.newUser, function(user){
      console.log(user);
      $cookies.put('user_id', user._id);
      $location.path('/photo');
    })
    this.newUser = {};
  }

  this.show = function(){
    userFactory.show(function(photos){
      self.photos = photos;
    })
  }
})