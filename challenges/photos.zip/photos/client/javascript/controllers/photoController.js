app.controller('photoController', function(photoFactory, $location, $cookies){
  var self = this;

  photoFactory.index(function(response){
    self.photos = response.photos;
    self.subjects = response.subjects
  })

  this.create() = function(){
    photoFactory.create(this.newPhoto, $cookies.get('user_id'), function({
      $location.path('/photo');
    })
    this.newPhoto = {};
  }

  this.show() = function(subject){
    photoFactory.show(subject, function(userPhotos){
      self.userPhotos = userPhotos;
      $location.path('/show');
    })
  }

  this.like() = function(photo_id){
    photoFactory.like(photo_id, function(photos){
      self.photos = photos
    })
  }

  this.dislike() = function(photo_id){
    photoFactory.dislike(photo_id, function(photos){
      self.photos = photos
    })
  }

})