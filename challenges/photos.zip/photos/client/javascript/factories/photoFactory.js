app.factory('photoFactory', function($http){
  return{

    index: function(callback){
      $http.get('/photos').success(function(response){
        callback(response);
      })
    },

    create: function(photo, user_id, callback){
      $http.post('/photos/' + user_id, photo).success(function(response){
        callback(response);
      })
    },

    show: function(subject, callback){
      $http.get('/photos/subject/' + subject).success(function(response){
        callback(response);
      })
    },

    like: function(photo_id, callback){
      $http.post('/photos/like' + photo_id).success(function(response){
        callback(response);
      })
    },

    dislike: function(photo_id, callback){
      $http.post('/photos/dislike' + photo_id).success(function(response){
        callback(response);
      })
    }
  }
})