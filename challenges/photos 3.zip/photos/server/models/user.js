var deepPopulate = require('mongoose-deep-populate')(mongoose);

var userSchema = new mongoose.Schema({
  first_name: String,
  last_name: String,
  photos: [{type: Schema.Types.ObjectId, ref: 'photo'}]
}, {timestamps: true});

mongoose.model('user', userSchema);

userSchema.plugin(deepPopulate);