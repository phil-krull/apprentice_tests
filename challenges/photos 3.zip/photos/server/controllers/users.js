var User = mongoose.model('user');

module.exports = {

  create: function(req, res){
    var newUser = req.body;
    User.create(newUser, function(errors, user){
      if(errors){
        res.send(erros);
      } else {
        res.json(user);
      }
    })
  },

  show: function(req, res){
    User.findOne({_id: req.params.id}).deepPopulate('photos photos._subject').lean().exec(function(errors, user){
      if(errors){
        res.send(errors)
      } else {
        for(var idx=0; idx<user.photos.length; idx++){
          var userLikes = false;
          for(var jdx=0; jdx<user.photos[idx].likes.length; jdx++){
            if(user.photos[idx].likes[jdx] == req.params.user_id){
              userLikes = true;
            }
          }
          if(userLikes){
            user.photos[idx].userLikes = true;
          } else {
            user.photos[idx].userLikes = false;
          }
        }
        res.json(user);
      }
    })
  }
}