app.factory('userFactory', function($http, $routeParams){
  return{
    create: function(user, callback){
      $http.post('/users', user).success(function(response){
        callback(response)
      });
    },

    show: function(user_id, callback){
      $http.get('/users/' + $routeParams.id + '/' + user_id).success(function(response){
        callback(response);
      })
    }
  }
})