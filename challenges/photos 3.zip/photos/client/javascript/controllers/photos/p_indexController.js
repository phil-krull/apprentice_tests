app.controller('p_indexController', function(photoFactory, $location, $cookies){
  var self = this;

  function get_photos(){
    photoFactory.index($cookies.get('user_id'), function(response){
      console.log(response);
      self.photos = response;
    })
  }

  get_photos();

  this.show = function(subject){
    photoFactory.show(subject, function(userPhotos){
      self.userPhotos = userPhotos;
      $location.path('/show');
    })
  }

  this.like = function(photo_id){
    photoFactory.like(photo_id, $cookies.get('user_id'), function(photos){
      get_photos();
    })
  }

  this.dislike = function(photo_id){
    photoFactory.dislike(photo_id, $cookies.get('user_id'),function(photos){
      get_photos();
    })
  }

})