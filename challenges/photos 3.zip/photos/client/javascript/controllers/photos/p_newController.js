app.controller('p_newController', function(photoFactory, $location, $cookies){
  var self = this;

  photoFactory.getSubjects(function(subjects){
    self.subjects = subjects;
  })

  this.create = function(){
    photoFactory.create(this.newPhoto, $cookies.get('user_id'), function(){
      $location.path('/photo');
    })
    this.newPhoto = {};
  }
})