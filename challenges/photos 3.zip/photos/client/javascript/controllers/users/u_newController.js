app.controller('u_newController', function(userFactory, $location, $cookies){
  var self = this;
  self.sessionUser;

  this.create = function(){
    userFactory.create(this.newUser, function(user){
      self.sessionUser = true;
      console.log(self.sessionUser);
      $cookies.put('user_id', user._id);
      $location.path('/photo');
    })
    this.newUser = {};
  }

  this.logout = function(){
    console.log('in logout');
    self.sessionUser = false;
    $cookies.remove('user_id');
    $location.path('/');
  }
})